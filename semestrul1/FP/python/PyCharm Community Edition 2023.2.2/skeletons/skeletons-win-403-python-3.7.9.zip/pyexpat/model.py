# encoding: utf-8
# module pyexpat.model
# from C:\BuildAgent\system\.persistent_cache\pycharm\pythons4utils\python37\DLLs\pyexpat.pyd
# by generator 1.147
""" Constants used to interpret content model information. """
# no imports

# Variables with simple values

XML_CQUANT_NONE = 0
XML_CQUANT_OPT = 1
XML_CQUANT_PLUS = 3
XML_CQUANT_REP = 2

XML_CTYPE_ANY = 2
XML_CTYPE_CHOICE = 5
XML_CTYPE_EMPTY = 1
XML_CTYPE_MIXED = 3
XML_CTYPE_NAME = 4
XML_CTYPE_SEQ = 6

__loader__ = None

__spec__ = None

# no functions
# no classes

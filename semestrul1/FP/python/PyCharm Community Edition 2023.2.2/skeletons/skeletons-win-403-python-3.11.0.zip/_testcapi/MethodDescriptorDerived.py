# encoding: utf-8
# module _testcapi
# from C:\BuildAgent\system\.persistent_cache\pycharm\pythons4utils\python311\DLLs\_testcapi.pyd
# by generator 1.147
# no doc
# no imports

from .MethodDescriptorBase import MethodDescriptorBase

class MethodDescriptorDerived(MethodDescriptorBase):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass



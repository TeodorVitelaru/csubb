# encoding: utf-8
# module _testcapi
# from C:\BuildAgent\system\.persistent_cache\pycharm\pythons4utils\python311\DLLs\_testcapi.pyd
# by generator 1.147
# no doc
# no imports

from .object import object

class MethInstance(object):
    """ Class with normal (instance) methods to test calling conventions """
    def meth_fastcall(self, *args, **kwargs): # real signature unknown
        pass

    def meth_fastcall_keywords(self, *args, **kwargs): # real signature unknown
        pass

    def meth_noargs(self, *args, **kwargs): # real signature unknown
        pass

    def meth_o(self, *args, **kwargs): # real signature unknown
        pass

    def meth_varargs(self, *args, **kwargs): # real signature unknown
        pass

    def meth_varargs_keywords(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass



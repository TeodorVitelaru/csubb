# encoding: utf-8
# module _testcapi
# from C:\BuildAgent\system\.persistent_cache\pycharm\pythons4utils\python311\DLLs\_testcapi.pyd
# by generator 1.147
# no doc
# no imports

from .object import object

class MethodDescriptorBase(object):
    # no doc
    def __call__(self, *args, **kwargs): # real signature unknown
        """ Call self as a function. """
        pass

    def __get__(self, *args, **kwargs): # real signature unknown
        """ Return an attribute of instance, which is of type owner. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass



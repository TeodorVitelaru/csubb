# encoding: utf-8
# module _testcapi
# from C:\BuildAgent\system\.persistent_cache\pycharm\pythons4utils\python311\DLLs\_testcapi.pyd
# by generator 1.147
# no doc
# no imports

from .object import object

class HeapDocCType(object):
    """ somedoc """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass



# encoding: utf-8
# module _testcapi
# from C:\BuildAgent\system\.persistent_cache\pycharm\pythons4utils\python311\DLLs\_testcapi.pyd
# by generator 1.147
# no doc
# no imports

from .object import object

class HeapCTypeWithWeakref(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    weakreflist = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default




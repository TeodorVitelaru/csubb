# encoding: utf-8
# module _testcapi
# from C:\BuildAgent\system\.persistent_cache\pycharm\pythons4utils\python311\DLLs\_testcapi.pyd
# by generator 1.147
# no doc
# no imports

from .object import object

class GenericAlias(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __mro_entries__(self, *args, **kwargs): # real signature unknown
        pass



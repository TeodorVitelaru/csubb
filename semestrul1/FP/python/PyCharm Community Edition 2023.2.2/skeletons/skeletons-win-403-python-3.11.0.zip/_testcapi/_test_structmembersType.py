# encoding: utf-8
# module _testcapi
# from C:\BuildAgent\system\.persistent_cache\pycharm\pythons4utils\python311\DLLs\_testcapi.pyd
# by generator 1.147
# no doc
# no imports

from .object import object

class _test_structmembersType(object):
    """ Type containing all structmember types """
    def __delattr__(self, *args, **kwargs): # real signature unknown
        """ Implement delattr(self, name). """
        pass

    def __getattribute__(self, *args, **kwargs): # real signature unknown
        """ Return getattr(self, name). """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __setattr__(self, *args, **kwargs): # real signature unknown
        """ Implement setattr(self, name, value). """
        pass

    T_BOOL = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    T_BYTE = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    T_DOUBLE = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    T_FLOAT = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    T_INT = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    T_LONG = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    T_LONGLONG = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    T_PYSSIZET = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    T_SHORT = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    T_STRING_INPLACE = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    T_UBYTE = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    T_UINT = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    T_ULONG = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    T_ULONGLONG = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    T_USHORT = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default




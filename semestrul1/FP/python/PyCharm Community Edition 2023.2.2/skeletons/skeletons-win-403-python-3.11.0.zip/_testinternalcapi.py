# encoding: utf-8
# module _testinternalcapi
# from C:\BuildAgent\system\.persistent_cache\pycharm\pythons4utils\python311\DLLs\_testinternalcapi.pyd
# by generator 1.147
# no doc
# no imports

# Variables with simple values

SIZEOF_PYGC_HEAD = 16

# functions

def DecodeLocaleEx(*args, **kwargs): # real signature unknown
    pass

def EncodeLocaleEx(*args, **kwargs): # real signature unknown
    pass

def get_config(*args, **kwargs): # real signature unknown
    pass

def get_configs(*args, **kwargs): # real signature unknown
    pass

def get_getpath_codeobject(*args, **kwargs): # real signature unknown
    pass

def get_recursion_depth(*args, **kwargs): # real signature unknown
    pass

def normalize_path(*args, **kwargs): # real signature unknown
    pass

def reset_path_config(*args, **kwargs): # real signature unknown
    pass

def set_config(*args, **kwargs): # real signature unknown
    pass

def set_eval_frame_default(*args, **kwargs): # real signature unknown
    pass

def set_eval_frame_record(*args, **kwargs): # real signature unknown
    pass

def test_atomic_funcs(*args, **kwargs): # real signature unknown
    pass

def test_bit_length(*args, **kwargs): # real signature unknown
    pass

def test_bswap(*args, **kwargs): # real signature unknown
    pass

def test_edit_cost(*args, **kwargs): # real signature unknown
    pass

def test_hashtable(*args, **kwargs): # real signature unknown
    pass

def test_popcount(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x000001BD6AADF650>'

__spec__ = None # (!) real value is "ModuleSpec(name='_testinternalcapi', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x000001BD6AADF650>, origin='C:\\\\BuildAgent\\\\system\\\\.persistent_cache\\\\pycharm\\\\pythons4utils\\\\python311\\\\DLLs\\\\_testinternalcapi.pyd')"


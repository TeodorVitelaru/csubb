# encoding: utf-8
# module _testinternalcapi
# from C:\BuildAgent\system\.persistent_cache\pycharm\pythons4utils\python39\DLLs\_testinternalcapi.pyd
# by generator 1.147
# no doc
# no imports

# Variables with simple values

SIZEOF_PYGC_HEAD = 16

# functions

def get_configs(*args, **kwargs): # real signature unknown
    pass

def get_recursion_depth(*args, **kwargs): # real signature unknown
    pass

def test_bswap(*args, **kwargs): # real signature unknown
    pass

def test_hashtable(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x0000019ACFD15DF0>'

__spec__ = None # (!) real value is "ModuleSpec(name='_testinternalcapi', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x0000019ACFD15DF0>, origin='C:\\\\BuildAgent\\\\system\\\\.persistent_cache\\\\pycharm\\\\pythons4utils\\\\python39\\\\DLLs\\\\_testinternalcapi.pyd')"


# encoding: utf-8
# module typing.re
# from C:\BuildAgent\system\.persistent_cache\pycharm\pythons4utils\python310\DLLs\_asyncio.pyd
# by generator 1.147
""" Wrapper namespace for re type aliases. """
# no imports

# functions

def Match(*args, **kwargs): # real signature unknown
    """ A generic version of re.Match. """
    pass

def Pattern(*args, **kwargs): # real signature unknown
    """ A generic version of re.Pattern. """
    pass

# no classes
# variables with complex values

__all__ = [
    'Pattern',
    'Match',
]

__weakref__ = None # (!) real value is "<attribute '__weakref__' of 'typing.re' objects>"


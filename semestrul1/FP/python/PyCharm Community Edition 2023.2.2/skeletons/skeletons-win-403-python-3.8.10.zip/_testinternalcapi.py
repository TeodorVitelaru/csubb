# encoding: utf-8
# module _testinternalcapi
# from C:\BuildAgent\system\.persistent_cache\pycharm\pythons4utils\python38\DLLs\_testinternalcapi.pyd
# by generator 1.147
# no doc
# no imports

# functions

def get_configs(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x00000269D8434790>'

__spec__ = None # (!) real value is "ModuleSpec(name='_testinternalcapi', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x00000269D8434790>, origin='C:\\\\BuildAgent\\\\system\\\\.persistent_cache\\\\pycharm\\\\pythons4utils\\\\python38\\\\DLLs\\\\_testinternalcapi.pyd')"

